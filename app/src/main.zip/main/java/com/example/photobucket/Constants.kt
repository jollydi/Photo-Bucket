package com.example.photobucket

object Constants {

    const val TAG = "pics app"
}